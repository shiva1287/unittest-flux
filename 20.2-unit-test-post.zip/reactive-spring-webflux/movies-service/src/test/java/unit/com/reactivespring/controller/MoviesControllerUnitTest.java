package com.reactivespring.controller;

public class MoviesControllerUnitTest {
}
